/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/**
 * Created by fhuertas on 6/08/15.
 */
{
    var StatisticsOnline = function (view) {
        this._view = view;
        this._charts = [];
        this._xaxisformat = StatisticsOnline.XAXIS_FORMAT_DIFFERENCE;
        this._default_time     = (this._view.time != undefined)?this._view.time:StatisticsOnline.DEFAULT_TIME;
        this._default_offset   = StatisticsOnline.DEFAULT_TIME_OFFSET;
        this._ticks_separation = (this._view.ticks_separation != undefined)?this._view.ticks_separation:StatisticsOnline.DEFAULT_TICKS_SEPARATION;
        this._deafult_max      = (this._view.max != undefined)?this._view.max:StatisticsOnline.YAXIS_DEFAULT_MAX;
        this._deafult_min      = (this._view.min != undefined)?this._view.min:StatisticsOnline.YAXIS_DEFAULT_MIN;
        this._deafult_mark     = (this._view.mark != undefined)?this._view.mark:StatisticsOnline.YAXIS_DEFAULT_MARK;
        //this._options =
        //this._options.xaxis.ticks = this._options.xaxis.ticks.bind(this)


        var sortedKeys = Object.keys(this._view.charts).sort();
        for (var i = 0; i < sortedKeys.length; i++) {
            var chart = {};
            chart.xaxisformat = this._xaxisformat;
            chart.description = this._view.charts[sortedKeys[i]];
            chart.id = sortedKeys[i];
            chart.series = []
            if (chart.description.max == undefined) {chart.description.max = this._deafult_max;}
            if (chart.description.min == undefined) {chart.description.min = this._deafult_min;}
            if (chart.description.graph_time == undefined) {chart.description.graph_time = this._default_time;}
            if (chart.description.offset == undefined) {chart.description.offset = this._default_offset;}
            if (chart.description.mark == undefined){chart.description.mark = this._deafult_mark};

            if (chart.description.ticks_separation == undefined) {
                 chart.description.ticks_separation = this._ticks_separation;
            }


            /*Setting graph options*/
            chart.options =$.extend(true, {}, StatisticsOnline.FLOT_OPTIONS);
            chart.options.xaxis.ticks = chart.options.xaxis.ticks.bind(chart)
            chart.options.yaxis.max = chart.description.max;
            chart.options.yaxis.min = chart.description.min;
            var xaxix = StatisticsOnline.calculateXAxis(chart);
            chart.options.xaxis.min = xaxix.min;
            chart.options.xaxis.max = xaxix.max;

            var diff = (chart.description.max - chart.description.min) * 0.005;
            var up = parseInt(chart.description.mark) + diff;
            var down = parseInt(chart.description.mark) - diff;
            chart.options.grid.markings = [
                { yaxis: { from: down, to: up}, color: "#FF0000" }
            ]
            chart.options.yaxis.ticks = 10;//parseInt((chart.options.yaxis.max - chart.options.yaxis.min)/5);
            this._charts.push(chart);
        }

        $("#" + StatisticsOnline.HEADER_ID).text(this._view.title);
    };


    StatisticsOnline.HEADER_ID = "so-title"
    StatisticsOnline.GRAPH_CLASS = "so-graph-div"
    StatisticsOnline.GRAPH_ID = "so-graph-div-"
    StatisticsOnline.GRAPH_MENU_ID = "so-graph-menu-"
    StatisticsOnline.GRAPH_MENU_CLASS = "so-graph-menu"
    StatisticsOnline.GRAPH_MENU_CSS_TITLE = "so-menu-title"
    StatisticsOnline.GRAPHS_CONTAINER_ID = "so-graphs"
    StatisticsOnline.GRAPTH_TITLE_CLASS = "so-graph-title"
    StatisticsOnline.GRAPTH_LEGEND_CLASS = "so-legend"
    StatisticsOnline.GRAPTH_LEGEND_ENTRY_CLASS = "so-legend-entry"
    StatisticsOnline.GRAPTH_LEGEND_ENTRY_KEY_CLASS = "so-graph-legend-key"
    StatisticsOnline.GRAPTH_LEGEND_ENTRY_VALUE_CLASS = "so-graph-legend-value"
    StatisticsOnline.YAXIS_LABEL_CLASS= "so-axis-label"
    StatisticsOnline.LEGEND_PREFIX = "so-";
    StatisticsOnline.DEFAULT_TIME = "120000"
    StatisticsOnline.DEFAULT_TIME_OFFSET = "1000"
    StatisticsOnline.DEFAULT_TICKS_SEPARATION = "20000"

    StatisticsOnline.XAXIS_FORMAT_DIFFERENCE = 0
    StatisticsOnline.XAXIS_FORMAT_DATE = 1

    StatisticsOnline.YAXIS_DEFAULT_MAX = 20
    StatisticsOnline.YAXIS_DEFAULT_MIN = 0
    StatisticsOnline.YAXIS_DEFAULT_MARK = 10



    StatisticsOnline.FLOOT_CONTAINER_CLASS = "so-flot-element"
    StatisticsOnline.FLOT_OPTIONS = {
        yaxis: {
            min: StatisticsOnline.YAXIS_DEFAULT_MIN,
            //tickSize: 2,
            ticks: 10,
            max: StatisticsOnline.YAXIS_DEFAULT_MAX
        },
        xaxis: {
            mode: 'time',
            //max:function () {return (new Date().getTime()-StatisticsOnline.DEFAULT_TIME_OFFSET)}
            max:(new Date().getTime()-StatisticsOnline.DEFAULT_TIME_OFFSET),
            min:(new Date().getTime()-StatisticsOnline.DEFAULT_TIME-StatisticsOnline.DEFAULT_TIME_OFFSET),
            ticks: function (axis) {
                if (this.xaxisformat == StatisticsOnline.XAXIS_FORMAT_DATE) {
                    return []
                } else {
                    var date = new Date(axis.max)
                    var actual = axis.max;
                    var end = axis.min;
                    var sDate = (date.getHours() < 10 ? "0" + date.getHours() : date.getHours()) + ":" +
                        (date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes()) + ":" +
                        (date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds());
                    var ticks = [[actual, "0"]];
                    actual -= this.description.ticks_separation;
                    var i = 0;
                    while (actual > end) {
                        i += parseInt(this.description.ticks_separation / 1000);
                        var sec = i % 60;
                        var cad = sec +"s"
                        if (i >= 60){
                            var min = parseInt(i / 60);
                            cad = min + "m "+cad
                        }
                        cad = "["+cad+"]"
                        ticks.push([actual, cad])
                        actual -= this.description.ticks_separation
                    }
                    return ticks

                }
            },

        },
        grid: {
            backgroundColor: "#ffffff",
            tickColor: "#585858",
            /*Red line*/
            markings:[
                { yaxis: { from: 9.90, to: 10.10}, color: "#FF0000" }
            ]
        }

    }

    StatisticsOnline.prototype.loadChart = function (chart,series) {
        var template = $("."+StatisticsOnline.GRAPH_CLASS+"."+TEMPLATE_CLASS);
        var graphsContainer = $("#"+StatisticsOnline.GRAPHS_CONTAINER_ID);


        var graphContainer = template.clone().removeClass(TEMPLATE_CLASS);
        graphContainer.attr('id',StatisticsOnline.GRAPH_ID+chart.id);
        var contextmenu = $.contextMenu({
            selector: '#'+StatisticsOnline.GRAPH_ID+chart.id,
            className: StatisticsOnline.GRAPH_MENU_CSS_TITLE,
            callback: function(key, options) {
                var m = "clicked: " + key;
                window.console && console.log(m) || alert(m);
            },
            items: {
                "graph_values" :  {
                    "name" : "Graphs Lines",
                    "items" : {
                    }

                },
                "legend_values" : {
                    "name" : "Legend Values",
                    items : {
                    }

                },
            }
        })
        //$('.context-menu-one').on('click', function(e){
        //    console.log('clicked', this);
        //})
        //var contextMenu = graphContainer.find("."+StatisticsOnline.GRAPH_MENU_CLASS);
        //contextMenu.attr('id',StatisticsOnline.GRAPH_MENU_ID+chart.id);
        //graphContainer.attr('contextmenu',StatisticsOnline.GRAPH_MENU_ID+chart.id);
        var legendEntryTemplate = graphContainer.find("."+StatisticsOnline.GRAPTH_LEGEND_ENTRY_CLASS+"."+TEMPLATE_CLASS);
        var legendContainer = graphContainer.find("."+StatisticsOnline.GRAPTH_LEGEND_CLASS);
        chart.container = graphContainer;
        if (chart.description.label) {
            graphContainer.find("."+StatisticsOnline.YAXIS_LABEL_CLASS).text(chart.description.label)
        }
        var sortedKeys = Object.keys(chart.description.legend).sort();
        for (var j = 0; j < sortedKeys.length;j++) {
            var legendEntry = legendEntryTemplate.clone().removeClass(TEMPLATE_CLASS).attr('id',StatisticsOnline.getLegendId(chart,chart.description.legend[sortedKeys[j]].id));
            legendEntry.find("."+StatisticsOnline.GRAPTH_LEGEND_ENTRY_KEY_CLASS).text(chart.description.legend[sortedKeys[j]].text)
            if (chart.description.legend[sortedKeys[j]].color){
                legendEntry.css('color',chart.description.legend[sortedKeys[j]].color);
            }
            legendContainer.append(legendEntry)
        }
        chart.flotContainer = chart.container.find("."+StatisticsOnline.FLOOT_CONTAINER_CLASS)
        if (chart.description.values == undefined || chart.description.values.length == 0){
            graphContainer.find('.'+StatisticsOnline.FLOOT_CONTAINER_CLASS).css('display','none');
            chart.series = []
            chart.seriesByKey = {};

        } else {
            sortedKeys = Object.keys(chart.description.values).sort();
            graphContainer.find('.'+StatisticsOnline.FLOOT_CONTAINER_CLASS).css('display','');
            if (series == undefined) {
                chart.series = []
                chart.seriesByKey = {};
                for (var j = 0; j < sortedKeys.length; j++) {
                    var key = chart.description.values[sortedKeys[j]].id;
                    var fill = chart.description.values[sortedKeys[j]].fill === "true";
                    var color = chart.description.values[sortedKeys[j]].color;
                    var series = {
                        data: [],
                        color: color,
                        lines: {
                            fill: fill,
                        },
                    }
                    chart.series.push(series)
                    chart.seriesByKey[key] = series;

                }
            } else {
                chart.series = series.series;
                chart.seriesByKey = series.seriesByKey;
                if (chart.description.flex_height == "true") {
                    var min = chart.description.min;
                    var max = chart.description.max;
                    for (var i = 0; i < chart.series.length; i++) {
                        var series = chart.series[i]
                        for (j = 0; j < series.data.length; j++) {
                            if (series.data[j][1] > max) {
                                max = series.data[j][1]
                            } else if (series.data[j][1] < min) {
                                min = series.data[j][1]
                            }
                        }
                    }
                    chart.options.yaxis.max = max;
                    chart.options.yaxis.min = min;

                }
            }
        }
        var connection = {}
        //connection.url = chart.description.url;
        chart.socket = new ReconnectingWebSocket(chart.description.url);
        chart.socket.onmessage = function (chart,e) {
            var msg = JSON.parse(e.data)
            this.newMessage(chart,msg);
        }.bind(this,chart)
        //chart.socket = new ReconnectingWebSocket(chart.description.url);
        //chart.socket.onopen(function (event) {
        //    console.log(event);
        //})

        //wsTest.onerror(function (a,b,c) {
        //    console.log(a+b+c);
        //})
        //chart.socket = io.connect(chart.description.url);
        ////chart.socket.on(chart.description.ws_tag,function (chart,msg){
        //chart.socket.on('message',function (chart,msg){
        //    this.newMessage(chart,msg);
        //}.bind(this,chart))
        //chart.socket.on('connect',function (a,b,c) {
        //    console.log(a+b+c);
        //})
        //chart.socket.on('error', function(a,b,c) {
        //    console.log('there was an error'+a+b+c);
        //});

        // Timeout because the div is not painted and it don't has width and height
        if(chart.series.length != 0) {
            setTimeout(function (chart) {
                chart.plot = $.plot(chart.flotContainer, chart.series, chart.options);
                var update = function (chart) {
                    this.refreshChart(chart)
                    setTimeout(update, 100)
                }.bind(this, chart)
                setTimeout(update, 100)
                //$.plot(chart.flotContainer,[],options)
            }.bind(this, chart), 1)
        }

        graphContainer.find("."+StatisticsOnline.GRAPTH_TITLE_CLASS).text(chart.description.title)

        graphsContainer.append(graphContainer);
    }

    StatisticsOnline.prototype.loadCharts = function () {
        for (var i = 0; i < this._charts.length; i++) {
            this.loadChart(this._charts[i])
        }
        $(window).resize(function (){
            var template = $("."+StatisticsOnline.GRAPH_CLASS+"."+TEMPLATE_CLASS).clone();
            $("."+StatisticsOnline.GRAPH_CLASS).remove();
            $("#"+StatisticsOnline.GRAPHS_CONTAINER_ID).append(template);
            for (var i = 0; i < this._charts.length; i++) {
                var series = {series: this._charts[i].series, seriesByKey: this._charts[i].seriesByKey}
                this.loadChart(this._charts[i],series)
            }
        }.bind(this))
    }

    StatisticsOnline.calculateXAxis = function (chart) {
        var times = {}
        times.max = new Date().getTime() - chart.description.offset;
        times.min = times.max - chart.description.graph_time;
        return times;
    }

    StatisticsOnline.prototype.refreshChart = function (chart) {
        var xaxis = StatisticsOnline.calculateXAxis(chart)
        chart.plot.getOptions().xaxes[0].max = xaxis.max
        chart.plot.getOptions().xaxes[0].min = xaxis.min;
        chart.plot.setupGrid();
        //chart.series[0].data.splice(0,0,[new Date().getTime() ,Math.random()* 20])
        var removeHight = false;
        var removeLow = false;
        for (var i = 0; i < chart.series.length;i++){
            var series = chart.series[i];
            while (series.data.length > 0 && series.data[series.data.length -1][0] < xaxis.min) {
                var value = series.data.pop();
                if (value[1] > chart.description.max) {
                    removeHight = true;
                } else if (value[1] < chart.description.min) {
                    removeLow = true;
                }
            }
        }
        if (removeHight || removeLow) {
            var max = chart.description.max
            var min = chart.description.min
            for (var i = 0; i < chart.series.length;i++){
                var series = chart.series[i];
                for (var j = 0; j < series.data.length;j++) {
                    if (max < series.data[j][1]) {
                        max = series.data[j][1];
                    } else if (min > series.data[j][1]) {
                        min = series.data[j][1];
                    }
                }
            }
            chart.plot.getOptions().yaxes[0].min = min;
            chart.plot.getOptions().yaxes[0].max = max;
            chart.plot.setupGrid();
        }
        chart.plot.draw();
    }

    StatisticsOnline.getLegendId = function (chart,key) {
        return StatisticsOnline.LEGEND_PREFIX + chart.id + "-"+key;
    }

    StatisticsOnline.prototype.newMessage = function (chart,msg) {
        $.each(msg.content,function (key,value){
            // Legend
            var id = StatisticsOnline.getLegendId(chart,key);
            $(document.getElementById(id)).find("."+StatisticsOnline.GRAPTH_LEGEND_ENTRY_VALUE_CLASS).text(value);

            // chart
            if (chart.seriesByKey[key] != undefined) {
                if (chart.description.flex_height) {
                    var changed = false;
                    if (chart.plot.getOptions().yaxes[0].max < value) {
                        chart.plot.getOptions().yaxes[0].max = value
                        changed = true;
                    }
                    if (chart.plot.getOptions().yaxes[0].min > value) {
                        chart.plot.getOptions().yaxes[0].min = value;
                        changed = true;
                    }
                    if (changed) {
                        //chart.options.yaxis.ticks = 10;//parseInt((chart.plot.getOptions().yaxes[0].max - chart.plot.getOptions().yaxes[0].min)/10);
                        //chart.options.yaxis.tickSize = parseInt((chart.options.yaxis.max - chart.options.yaxis.min)/5);

                        var diff = (chart.plot.getOptions().yaxes[0].max - chart.plot.getOptions().yaxes[0].min) * 0.005;
                        diff = diff.toFixed(2)

                        var up = parseInt(chart.description.mark) + parseFloat(diff);
                        var down = parseInt(chart.description.mark) - parseFloat(diff);
                        chart.plot.getOptions().grid.markings = [
                            { yaxis: { from: down, to: up}, color: "#FF0000" }
                        ]
                        chart.plot.setupGrid();
                        chart.seriesByKey[key].data.splice(0,0,[new Date().getTime() ,value])
                        chart.plot.setData(chart.series)
                        chart.plot.draw();

                    }
                }


                chart.seriesByKey[key].data.splice(0,0,[new Date().getTime() ,value])
                chart.plot.setData(chart.series)
                chart.plot.draw();
            }
        })

    }
}