       $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro1/monitoro1/optimizadorD-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
        $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload2").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro2/monitoro2/optimizadorC-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
        $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload3").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro1/monitoro1/memory-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
        $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload4").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro2/monitoro2/memory-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
        $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload5").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro1/monitoro1/cpu-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
        $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload6").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro2/monitoro2/cpu-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
        $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload7").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro1/monitoro1/optimizadorC-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
        $(document).ready(function() {
	$.ajaxSetup({cache: false}); // fixes older IE caching bug
		setInterval(function(){
	    		$("#reload8").attr("src", "http://10.250.0.22:8060/solowan/monitor/monitoro2/monitoro2/optimizadorD-day.png?"+new Date().getTime());
		},300000); //reload every 5min 
	});
