/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/**
 * Created by fhuertas on 6/08/15.
 */
{
    var StatisticsOnline = function (view) {
        this._view = view;
        this._charts = [];
        this._xaxisformat = StatisticsOnline.XAXIS_FORMAT_DIFFERENCE;
        this._default_time     = (this._view.time != undefined)?this._view.time:StatisticsOnline.DEFAULT_TIME;
        this._default_offset   = StatisticsOnline.DEFAULT_TIME_OFFSET;
        this._ticks_separation = (this._view.ticks_separation != undefined)?this._view.ticks_separation:StatisticsOnline.DEFAULT_TICKS_SEPARATION;
        this._deafult_max      = (this._view.max != undefined)?this._view.max:StatisticsOnline.YAXIS_DEFAULT_MAX;
        this._deafult_min      = (this._view.min != undefined)?this._view.min:StatisticsOnline.YAXIS_DEFAULT_MIN;
        this._deafult_mark     = (this._view.mark != undefined)?this._view.mark:StatisticsOnline.YAXIS_DEFAULT_MARK;
        //this._options =
        //this._options.xaxis.ticks = this._options.xaxis.ticks.bind(this)


        var sortedKeys = Object.keys(this._view.charts).sort();
        for (var i = 0; i < sortedKeys.length; i++) {
            //var chart = {};
            //var chart = new Chart();

            var xaxisformat = this._xaxisformat;
            //chart.description = this._view.charts[sortedKeys[i]];
            //chart.id = sortedKeys[i];
            //chart.series = []
            var description = this._view.charts[sortedKeys[i]];
            if (description.max == undefined) {description.max = this._deafult_max;}
            if (description.min == undefined) {description.min = this._deafult_min;}
            if (description.graph_time == undefined) {description.graph_time = this._default_time;}
            if (description.offset == undefined) {description.offset = this._default_offset;}
            if (description.mark == undefined){description.mark = this._deafult_mark};

            if (description.ticks_separation == undefined) {description.ticks_separation = this._ticks_separation;}


            /*Setting graph options*/

            var chart = new Chart(sortedKeys[i], description,xaxisformat);

            this._charts.push(chart);
        }

        $("#" + StatisticsOnline.HEADER_ID).text(this._view.title);
    };


    StatisticsOnline.HEADER_ID = "so-title"
    StatisticsOnline.GRAPH_CLASS = "so-graph-div"
    StatisticsOnline.GRAPH_ID = "so-graph-div-"
    StatisticsOnline.GRAPH_MENU_ID = "so-graph-menu-"
    StatisticsOnline.GRAPH_MENU_CLASS = "so-graph-menu"
    StatisticsOnline.GRAPH_MENU_CSS_TITLE = "so-menu-title"
    StatisticsOnline.GRAPHS_CONTAINER_ID = "so-graphs"
    StatisticsOnline.GRAPTH_TITLE_CLASS = "so-graph-title"
    StatisticsOnline.GRAPTH_LEGEND_CLASS = "so-legend"
    StatisticsOnline.GRAPTH_LEGEND_ENTRY_CLASS = "so-legend-entry"
    StatisticsOnline.GRAPTH_LEGEND_ENTRY_KEY_CLASS = "so-graph-legend-key"
    StatisticsOnline.GRAPTH_LEGEND_ENTRY_VALUE_CLASS = "so-graph-legend-value"
    StatisticsOnline.YAXIS_LABEL_CLASS= "so-axis-label"
    StatisticsOnline.LEGEND_PREFIX = "so-";
    StatisticsOnline.DEFAULT_TIME = "120000"
    StatisticsOnline.DEFAULT_TIME_OFFSET = "1000"
    StatisticsOnline.DEFAULT_TICKS_SEPARATION = "20000"

    StatisticsOnline.XAXIS_FORMAT_DIFFERENCE = 0
    StatisticsOnline.XAXIS_FORMAT_DATE = 1

    StatisticsOnline.YAXIS_DEFAULT_MAX = 20
    StatisticsOnline.YAXIS_DEFAULT_MIN = 0
    StatisticsOnline.YAXIS_DEFAULT_MARK = 10

    StatisticsOnline.VOID_SERIES = {
        data: [],
    }
    StatisticsOnline.left_menu =  {
        items: {
            "configured" :  {
                "name"  : "Variables configured",
                "items" : {}

            },
            "received" : {
                "name" : "Variables received",
                items  : {}

            },
        },
    }

    StatisticsOnline.FLOOT_CONTAINER_CLASS = "so-flot-element"

    StatisticsOnline.updateChart = function (chart){

        chart.series.push(StatisticsOnline.VOID_SERIES);
        chart.plot = $.plot(chart.flotContainer, chart.series, chart.options);
        this.refreshChart(chart)
        setTimeout(StatisticsOnline.updateChart.bind(this,chart),100);
        return true;
    }



    StatisticsOnline.prototype.loadCharts = function () {
        for (var i = 0; i < this._charts.length; i++) {
            this._charts[i].loadChart()
        }
        $(window).resize(function (){
            var template = $("."+StatisticsOnline.GRAPH_CLASS+"."+TEMPLATE_CLASS).clone();
            $("."+StatisticsOnline.GRAPH_CLASS).remove();
            $("#"+StatisticsOnline.GRAPHS_CONTAINER_ID).append(template);
            for (var i = 0; i < this._charts.length; i++) {
                var series = {series: this._charts[i].series, seriesByKey: this._charts[i].seriesByKey}
                this._charts[i].loadChart();
                //this.loadChart(this._charts[i],series)
            }
        }.bind(this))
    }
}
{
    var Chart = function (id, description,xaxisformat) {
        this._loopColors = {i:0, colors: chroma.brewer['Paired']};
        this._seriesByKey = {};
        this._id = id;
        this._description = description;

        this._options = $.extend(true, {}, Chart.FLOT_OPTIONS);
        //chart.options =$.extend(true, {}, StatisticsOnline.FLOT_OPTIONS);
        this._options.xaxis.ticks = this._options.xaxis.ticks.bind(this)
        //this._options.yaxis.max = this._description.max;
        //this._options.yaxis.min = this._description.min;
        this.calculateXAxis();
        this.calculateYAxis(this._description.min,this._description.max);
        // DELETE
        //var xaxix = StatisticsOnline.calculateXAxis(chart);
        //options.xaxis.min = xaxix.min;
        //options.xaxis.max = xaxix.max;

        var diff = (this._description.max - this._description.min) * 0.005;
        var up = parseInt(this._description.mark) + diff;
        var down = parseInt(this._description.mark) - diff;
        this._options.grid.markings = [
            { yaxis: { from: down, to: up}, color: "#FF0000" }
        ]
        this._options.yaxis.ticks = 10;//parseInt((chart.options.yaxis.max - chart.options.yaxis.min)/5);
        this._xaxisformat = xaxisformat;
        this._plot = undefined;
        this._variables = {};
        this._menuItems = {_separation: "-"};
        this.updateChart();
        this.cleanProcess();

    }
    Chart.prototype.getNextColor = function () {
        var color = this._loopColors.colors[this._loopColors.i++]
        if (this._loopColors.i == this._loopColors.colors.length) {
            this._loopColors.i = 0;
        }
        return color;
    }
    Chart.prototype.addSeries = function (key,series) {
        this._seriesByKey[key] = series;
    }

    Chart.prototype.setAllSeries = function (series) {
        this._seriesByKey = series;
    }

    Chart.prototype.getVariables = function () {
        return this._variables;
    }

    Chart.prototype.getVariable = function (key) {
        return this._variables[key];
    }

    Chart.prototype.getMenuItems = function () {
        return this._menuItems;
    }

    Chart.prototype.getId = function () {
        return this._id;
    }

    Chart.prototype.addMenuItem = function (key,value) {
    }

    Chart.prototype.setVariableParams = function (key,chart,legend){
        if (chart || chart == undefined || chart == null) {
            this._variables[key].chart = true;
        } else {
            this._variables[key].chart = false;
        }
        if (legend || legend == undefined || legend == null) {
            this._variables[key].legend = true;
        } else {
            this._variables[key].legend = false;
        }
        //this._menuItems[key].items.graph.selected =  this._variables[key].chart;
        //this._menuItems[key].items.legend.selected =  this._variables[key].legend;
    }

    Chart.prototype.addVariable = function (key,series) {
        if (this._variables[key] == undefined) {
            this._variables[key] = {};
            this._variables[key].series = series;
            this.addMenuItem(key, this._variables[key]);
        }
        return this._variables;

    }

    Chart.prototype.calculateXAxis = function (min,max) {
        this._options.xaxis.max = (max == undefined)?new Date().getTime() - this._description.offset:max;
        this._options.xaxis.min = (min == undefined)?this._options.xaxis.max-this._description.graph_time:min;
        if (this.getPlot() != undefined) {
            this.getPlot().getOptions().xaxes[0].max = this._options.xaxis.max
            this.getPlot().getOptions().xaxes[0].min = this._options.xaxis.min;
            this.getPlot().setupGrid();
        }
    }

    Chart.prototype.getPlot = function (){
        return this._plot;
    }

    Chart.prototype.getDescription = function () {
        return this._description;
    }
    Chart.prototype.getActiveSeries = function () {
        var keys = Object.keys(this.getVariables());
        var series = []
        for (var i = 0; i < keys.length;i++) {
            if (this.getVariable(keys[i]).chart) {
                series.push(this.getVariable(keys[i]).series)
            }
        }
        if (series.length == 0) {
            return [Chart.VOID_SERIES]
        }
        return series;
    }

    Chart.prototype.updateChart = function (){
        if (this.getPlot() != undefined) {
            this.refreshChart()
        }
        setTimeout(this.updateChart.bind(this),100);
    }

    Chart.prototype.getGraphOptions = function () {
        return this._options;
    }

    Chart.prototype.setDomContainer = function (dom) {
        this._domContainer = dom;
        this._flotDomeContainer = this._domContainer.find("."+StatisticsOnline.FLOOT_CONTAINER_CLASS)
    }

    Chart.prototype.getDomContainer = function (){
        return this._domContainer;
    }

    Chart.prototype.getFlotContainer = function () {
        return this._flotDomeContainer;
    }

    Chart.prototype.setWebSocket = function (uri) {
        this._socket = new ReconnectingWebSocket(uri)
        this._socket.onmessage = function (e) {
            var msg = JSON.parse(e.data)
            // XXXX
            this.newMessage(msg);
        }.bind(this)
    }


    Chart.prototype.newMessage = function (msg) {
        //var series = this.getActiveSeries();
        if (this.getPlot() != undefined) {

            $.each(msg.content,function (key,value){
                // Legend
                var id = this.getLegendId(key);
                $(document.getElementById(id)).find("."+StatisticsOnline.GRAPTH_LEGEND_ENTRY_VALUE_CLASS).text(value);

                // chart
                //if (chart.seriesByKey[key] != undefined) {
                if (this.getVariable(key) != undefined) {
                    this.getVariable(key).series.data.splice(0,0,[new Date().getTime() ,value])
                }
            }.bind(this))

            //this.getPlot().setData(series)
            //this.getPlot().draw();
        }
    }

    Chart.prototype.refreshChart = function () {
        this.calculateXAxis();
        var series = this.getActiveSeries();
        if (this.getDescription().flex_height) {
            var min = series
                .map(function (entry) {
                    return entry.data
                }).reduce(function (series1,series2){
                   return series1.concat(series2)
                }).map(function (entry) {
                    return parseFloat(entry[1]);
                }).concat([parseFloat(this.getDescription().min)]).reduce(function(prev,actual) {
                    return (prev< actual)?prev:actual;
                })
            var max = series
                .map(function (entry) {
                    return entry.data
                }).reduce(function (series1,series2){
                    return series1.concat(series2)
                }).map(function (entry) {
                    return parseFloat(entry[1]);
                }).concat([parseFloat(this.getDescription().max)]).reduce(function(prev,actual) {
                    return (prev> actual)?prev:actual;
                })            //var dataMin = series.map(function(_array){            if (_array.data.length != 0) {


            this.calculateYAxis(min,max);
        }
        this.getPlot().setData(series)
        this.getPlot().draw();

        return true;
    }

    Chart.prototype.calculateYAxis = function (min, max) {
        this._options.yaxis.max = max;
        this._options.yaxis.min = min;
        if (this.getPlot() != undefined) {
            this.getPlot().getOptions().yaxes[0].min = min;
            this.getPlot().getOptions().yaxes[0].max = max;
            // RED LINE!!!!!

            var diff = (this.getPlot().getOptions().yaxes[0].max - this.getPlot().getOptions().yaxes[0].min) * 0.005;
            diff = diff.toFixed(2)

            if (this.getDescription().mark != undefined) {
                var up = parseInt(this.getDescription().mark) + parseFloat(diff);
                var down = parseInt(this.getDescription().mark) - parseFloat(diff);
                this.getPlot().getOptions().grid.markings = [
                    { yaxis: { from: down, to: up}, color: "#FF0000" }
                ]

            }

            this.getPlot().setupGrid();
        }
    }


    Chart.VOID_SERIES = {
        data: [],
    }

    Chart.prototype.getVariableKeys = function () {
        return Object.keys(this.getVariables());
    }

    Chart.prototype.cleanProcess = function () {
        var keys = this.getVariableKeys();
        keys.each(function (key) {
            this.getVariable(key).series.data = this.getVariable(key).series.data.filter(function (value){
                return this._options.xaxis.min < value[0];
            }.bind(this))
        }.bind(this))
        setTimeout(this.cleanProcess.bind(this),1000);
    }


    Chart.prototype.loadChart = function () {
        var template = $("."+StatisticsOnline.GRAPH_CLASS+"."+TEMPLATE_CLASS);
        var graphsContainer = $("#"+StatisticsOnline.GRAPHS_CONTAINER_ID);
        // deep clone

        var graphContainer = template.clone().removeClass(TEMPLATE_CLASS);
        graphContainer.attr('id',StatisticsOnline.GRAPH_ID+this.getId());

        var legendEntryTemplate = graphContainer.find("."+StatisticsOnline.GRAPTH_LEGEND_ENTRY_CLASS+"."+TEMPLATE_CLASS);
        var legendContainer = graphContainer.find("."+StatisticsOnline.GRAPTH_LEGEND_CLASS);
        this.setDomContainer(graphContainer);
        if (this.getDescription().label) {
            graphContainer.find("."+StatisticsOnline.YAXIS_LABEL_CLASS).text(this.getDescription().label)
        }
        var sortedKeys = Object.keys(this.getDescription().legend).sort();
        for (var j = 0; j < sortedKeys.length;j++) {
            if (this.getDescription().legend[sortedKeys[j]].color == undefined) {
                this.getDescription().legend[sortedKeys[j]].color = this.getNextColor();
            }
            var legendEntry = legendEntryTemplate.clone().removeClass(TEMPLATE_CLASS).attr('id',this.getLegendId(this.getDescription().legend[sortedKeys[j]].id));
            legendEntry.find("."+StatisticsOnline.GRAPTH_LEGEND_ENTRY_KEY_CLASS).text(this.getDescription().legend[sortedKeys[j]].text)
            if (this.getDescription().legend[sortedKeys[j]].color){
                legendEntry.css('color',this.getDescription().legend[sortedKeys[j]].color);
            }
            legendContainer.append(legendEntry);
            var legendKey = this.getDescription().legend[sortedKeys[j]].id;
            var legendSeries = {
                data: [],
                color: this.getDescription().legend[sortedKeys[j]].color,
                lines: {
                    fill: this.getDescription().legend[sortedKeys[j]].fill === "true",
                },
            }
            this.addVariable(legendKey,legendSeries)
            this.setVariableParams(legendKey,false,true);
        }
        if (this.getDescription().values == undefined || this.getDescription().values.length == 0){
            graphContainer.find('.'+StatisticsOnline.FLOOT_CONTAINER_CLASS).css('display','none');
        } else {
            sortedKeys = Object.keys(this.getDescription().values).sort();
            var activeSeries = this.getActiveSeries();
            graphContainer.find('.'+StatisticsOnline.FLOOT_CONTAINER_CLASS).css('display','');
            if (this.getDescription().flex_height == "true") {

                var min = this.getDescription().min;
                var max = this.getDescription().max;
                $.each(activeSeries,function (key,series) {
                    for (j = 0; j < series.data.length; j++) {
                        if (series.data[j][1] > max) {
                            max = series.data[j][1]
                        } else if (series.data[j][1] < min) {
                            min = series.data[j][1]
                        }
                    }
                })
                this._options.yaxis.max = max;
                this._options.yaxis.min = min;
            }

            for (var j = 0; j < sortedKeys.length; j++) {
                var key = this.getDescription().values[sortedKeys[j]].id;
                if (this.getDescription().values[sortedKeys[j]].color == undefined) {
                    this.getDescription().values[sortedKeys[j]].color = this.getNextColor();
                }
                var variableSeries = {
                    data: [],
                    color: this.getDescription().values[sortedKeys[j]].color,
                    lines: {
                        fill: this.getDescription().values[sortedKeys[j]].fill === "true",
                    },
                }
                this.addVariable(key,variableSeries)
                this.setVariableParams(key,true,false);
            }
        }
        this.setWebSocket(this.getDescription().url);

        /*AQUI**/
        setTimeout(function () {
            this._plot = $.plot(this.getFlotContainer(), this.getActiveSeries(), this.getGraphOptions());
            this.createMenuContextGraph();
            this.refreshGraphMenu();

        }.bind(this),1);

        graphContainer.find("."+StatisticsOnline.GRAPTH_TITLE_CLASS).text(this.getDescription().title)

        graphsContainer.append(graphContainer);
        context.init({preventDoubleContext: false});
        context.settings({compress: true});

    }

    Chart.prototype.getLegendId = function (key) {
        return StatisticsOnline.LEGEND_PREFIX + this.getId() + "-"+key;
    }

    Chart.CONTEXT_MENU_BASE = {
        visibleCursor: 2,
        hiddenCursor: 4,
        menu: [
            {header: 'Graph options', color: "Black"},
            {header: 'Variables showed'},
            {divider: true},
            {header: 'Variables hidden'},
    ]}

    Chart.prototype.createMenuContextGraph = function () {
        var keys = this.getVariableKeys();

        var visible = keys.filter(function (value) {
            return this.getVariable(value).chart;
        }.bind(this))

        var hidden = keys.filter(function (value) {
            return !this.getVariable(value).chart;
        }.bind(this))
        var menu = $.extend(true,{},Chart.CONTEXT_MENU_BASE);

        keys.each(function (key) {
            if (this.getVariable(key).chart) {
                var item = {
                    text : key,
                    color : this.getVariable(key).series.color,
                    action : function (key,e) {
                        this.getVariable(key).chart = false;
                        this.createMenuContextGraph()
                        this.refreshGraphMenu();
                    }.bind(this,key),
                }
                menu.menu.splice(menu.visibleCursor,0, item)
                menu.hiddenCursor++;
            } else {
                var item = {
                    text : key,
                    color : this.getVariable(key).series.color,
                    action : function (key,e) {
                        this.getVariable(key).chart = true;
                        this.createMenuContextGraph()
                        this.refreshGraphMenu();
                    }.bind(this,key)
                }
                menu.menu.splice(menu.hiddenCursor,0, item)
            }
        }.bind(this))
        this._graphMenu = menu;
        return menu;
    }

    Chart.prototype.refreshGraphMenu = function (menu) {
        if (menu == undefined){
            menu = this._graphMenu;
        }
        context.destroy('#'+StatisticsOnline.GRAPH_ID+this.getId()+' .so-flot-element',menu.menu)
        context.attach('#'+StatisticsOnline.GRAPH_ID+this.getId()+' .so-flot-element',menu.menu)
    }


    Chart.FLOT_OPTIONS = {
        yaxis: {
            min: StatisticsOnline.YAXIS_DEFAULT_MIN,
            ticks: 10,
            max: StatisticsOnline.YAXIS_DEFAULT_MAX
        },
        xaxis: {
            mode: 'time',
            //max:function () {return (new Date().getTime()-StatisticsOnline.DEFAULT_TIME_OFFSET)}
            max:(new Date().getTime()-StatisticsOnline.DEFAULT_TIME_OFFSET),
            min:(new Date().getTime()-StatisticsOnline.DEFAULT_TIME-StatisticsOnline.DEFAULT_TIME_OFFSET),
            ticks: function (axis) {
                if (this._xaxisformat == StatisticsOnline.XAXIS_FORMAT_DATE) {
                    return []
                } else {
                    var date = new Date(axis.max)
                    var actual = axis.max;
                    var end = axis.min;
                    var sDate = (date.getHours() < 10 ? "0" + date.getHours() : date.getHours()) + ":" +
                        (date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes()) + ":" +
                        (date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds());
                    var ticks = [[actual, "0"]];
                    actual -= this.getDescription().ticks_separation;
                    var i = 0;
                    while (actual > end) {
                        i += parseInt(this.getDescription().ticks_separation / 1000);
                        var sec = i % 60;
                        var cad = sec +"s"
                        if (i >= 60){
                            var min = parseInt(i / 60);
                            cad = min + "m "+cad
                        }
                        cad = "["+cad+"]"
                        ticks.push([actual, cad])
                        actual -= this.getDescription().ticks_separation
                    }
                    return ticks

                }
            },

        },
        grid: {
            backgroundColor: "#ffffff",
            tickColor: "#585858",
            /*Red line*/
            markings:[
                { yaxis: { from: 9.90, to: 10.10}, color: "#FF0000" }
            ]
        }

    }

}