/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/**
 * Created by fhuertas on 29/07/15.
 */


var MUNIN_HISTORY_PROPERTIES_URL = "props/views.properties"
var MUNIN_HISTORY_URL = "templates/munin.ejs"
var ONLINE_URL = "templates/online.ejs"
var STATISTICS_URL = "templates/statistics_online.ejs"



var view_loaded = undefined;
var views = {}

views.index = {}
views.index.url = "templates/welcome.ejs"


views.munin_history = []
views.onlineView = []
views.statistic_online = []
viewsIndex = {}

parsePropertiesUrl(MUNIN_HISTORY_PROPERTIES_URL,function (propertiesObject){
    var sortedKeys
    if (propertiesObject.munin_history != undefined) {
        sortedKeys = Object.keys(propertiesObject.munin_history).sort()
        for (var i = 0; i < sortedKeys.length; i++) {
            views.munin_history[i] = propertiesObject.munin_history[sortedKeys[i]];
            views.munin_history[i].id = sortedKeys[i];
            views.munin_history[i].url = MUNIN_HISTORY_URL;
            viewsIndex[sortedKeys[i]] = views.munin_history[i];
        }
    }
    if (propertiesObject.online_view != undefined) {
        sortedKeys = Object.keys(propertiesObject.online_view).sort()
        for (var i = 0; i < sortedKeys.length; i++) {
            views.onlineView[i] = propertiesObject.online_view[sortedKeys[i]]
            views.onlineView[i].id = sortedKeys[i];

            views.onlineView[i].url = ONLINE_URL;
            views.onlineView[i].menu = propertiesObject.online_view[sortedKeys[i]].menu;
            views.onlineView[i].title = propertiesObject.online_view[sortedKeys[i]].title;
            views.onlineView[i].connections = propertiesObject.online_view[sortedKeys[i]].connections;
            viewsIndex[sortedKeys[i]] = views.onlineView[i];
        }
    }

    if (propertiesObject.online_view != undefined) {
        sortedKeys = Object.keys(propertiesObject.statistic_online).sort()
        for (var i = 0; i < sortedKeys.length; i++) {
            views.statistic_online[i] = propertiesObject.statistic_online[sortedKeys[i]]
            views.statistic_online[i].id = sortedKeys[i]
            views.statistic_online[i].title = propertiesObject.statistic_online[sortedKeys[i]].title;
            views.statistic_online[i].menu = propertiesObject.statistic_online[sortedKeys[i]].menu;
            views.statistic_online[i].url = STATISTICS_URL;
            views.statistic_online[i].charts = propertiesObject.statistic_online[sortedKeys[i]].charts;
            viewsIndex[sortedKeys[i]] = views.statistic_online[i];
        }
    }
    load_menus(views)

    if (propertiesObject.default_view != undefined) {
        setTimeout(change_view.bind(this,viewsIndex[propertiesObject.default_view]),200);
    }
});


function change_view(view) {
    view_loaded = view;
    $("#"+MAIN_TAG_ID).empty();
    $("#"+MAIN_TAG_ID).html(new EJS ({url: view.url}).render())
}

var load_menus = function (views) {
    var historyDiv = $("#"+HISTORY_MENU_TAG_ID);
    var lineTemplate = historyDiv.find("li."+TEMPLATE_CLASS);
    historyDiv.empty();
    historyDiv.append(lineTemplate);

    //var sortedKeys;
    for (var i = 0; i < views.munin_history.length; i++) {
        var newLine = lineTemplate.clone().removeClass(TEMPLATE_CLASS);
        newLine.find("a").text(views.munin_history[i].menu)
        newLine.find("a").click(change_view.bind(this,views.munin_history[i]))
        historyDiv.append(newLine);

    }
    var onlineDiv = $("#"+ONLINE_MENU_TAG_ID);
    lineTemplate = historyDiv.find("li."+TEMPLATE_CLASS);
    onlineDiv.empty();
    onlineDiv.append(lineTemplate);
    for (var i = 0; i < views.onlineView.length;i++) {
        var newLine = lineTemplate.clone().removeClass(TEMPLATE_CLASS);
        newLine.find("a").text(views.onlineView[i].menu)
        newLine.find("a").click(change_view.bind(this,views.onlineView[i]))
        onlineDiv.append(newLine);
    }


    var statisticsDiv = $("#"+STATISTICS_MENU_TAG_ID);
    lineTemplate = statisticsDiv.find("li."+TEMPLATE_CLASS);
    statisticsDiv.empty();
    statisticsDiv.append(lineTemplate);
    for (var i = 0; i < views.statistic_online.length;i++) {
        var newLine = lineTemplate.clone().removeClass(TEMPLATE_CLASS);
        newLine.find("a").text(views.statistic_online[i].menu)
        newLine.find("a").click(change_view.bind(this,views.statistic_online[i]))
        statisticsDiv.append(newLine);
    }
};

